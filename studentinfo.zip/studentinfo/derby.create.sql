connect 'jdbc:derby://localhost:1527/studentinfo;create=true;user=root;password=123456';
CREATE TABLE student (
    id VARCHAR(10) NOT NULL,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    gender VARCHAR(6) NOT NULL,
    phone VARCHAR(11) NOT NULL,  
    id_card VARCHAR(18) NOT NULL,  
    college VARCHAR(50) NOT NULL,  
    major VARCHAR(50) NOT NULL,  
    PRIMARY KEY (id)
);
CREATE TABLE account (  
    id VARCHAR(10) NOT NULL,  
    role VARCHAR(20) NOT NULL,  
    password VARCHAR(50) NOT NULL,  
    PRIMARY KEY (id)  
);
INSERT INTO account (id, role, password) VALUES ('000000', 'admin', 'root');