connect 'jdbc:derby://localhost:1527/studentinfo;create=true;user=root;password=123456';
DROP TABLE student;
DROP TABLE account;