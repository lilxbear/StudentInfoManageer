/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package cn.edu.cjlu.studentinfomanager;

import cn.edu.cjlu.studentinfomanager.controller.MainController;

import javax.swing.*;
import java.util.Locale;

/**
 *
 * @author Wang Yi
 */

public class Studentinfomanager {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainController();
            }
        });
    }

}
