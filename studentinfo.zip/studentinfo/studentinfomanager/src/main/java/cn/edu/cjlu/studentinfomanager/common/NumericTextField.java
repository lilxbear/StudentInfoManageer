package cn.edu.cjlu.studentinfomanager.common;

import javax.swing.*;
import javax.swing.text.*;

/**
 * 
 * @author Fan Jiaying
 */

public class NumericTextField extends JTextField {

    private int limit;
    public NumericTextField(int limit) {
        super();
        this.limit = limit;
        AbstractDocument doc = (AbstractDocument) this.getDocument();
        doc.setDocumentFilter(new NumericDocumentFilter());
    }

    class NumericDocumentFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String str, AttributeSet attr) throws BadLocationException {
            if (str == null) {
                return;
            }
            if (!isNumeric(str)) {
                return;
            }
            if (fb.getDocument().getLength() + str.length() <= limit) {
                super.insertString(fb, offset, str, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text == null) {
                return;
            }
            if (!isNumeric(text)) {
                return;
            }
            if (fb.getDocument().getLength() + text.length() - length <= limit) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }
    private boolean isNumeric(String text) {
        for (int i = 0; i < text.length(); i++) {
            if (!Character.isDigit(text.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public int getNumericText() {
        String text = this.getText();
        if (isNumeric(text)) {
            return Integer.parseInt(text);
        } else {
            throw new IllegalArgumentException("Text is not numeric.");
        }
    }

}
