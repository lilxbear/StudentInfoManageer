package cn.edu.cjlu.studentinfomanager.common;

import cn.edu.cjlu.studentinfomanager.entity.Student;

import javax.swing.*;
import java.awt.*;

/**
 * 
 * @author Wang Yi
 */

public class StudentPanel extends JPanel {

    private JLabel idLabel;
    private JTextField idField;
    private JLabel nameLabel;
    private JTextField nameField;
    private JLabel ageLabel;
    private NumericTextField ageField;
    private JLabel genderLabel;
    private JComboBox genderComboBox;
    private JLabel phoneLabel;
    private NumericTextField phoneField;
    private JLabel idCardLabel;
    private NumericTextField idCardField;
    private JLabel collegeLabel;
    private JTextField collegeField;
    private JLabel majorLabel;
    private JTextField majorField;

    public StudentPanel() {
        this(null);
    }

    public StudentPanel(Student student) {
        super();
        setLayout(new GridLayout(8, 2));

        idLabel = new JLabel("ID:");
        add(idLabel);

        idField = new TextFieldLimit(10);
        if (student != null) {
            idField.setText(student.getId());
        } // The default value is an empty string
        add(idField);

        nameLabel = new JLabel("Name:");
        add(nameLabel);

        nameField = new TextFieldLimit(100);
        if (student != null) {
            nameField.setText(student.getName());
        } // The default value is an empty string
        add(nameField);

        ageLabel = new JLabel("Age:");
        add(ageLabel);

        ageField = new NumericTextField(3);
        if (student != null) {
            ageField.setText(String.valueOf(student.getAge()));
        } // The default value is an empty string
        add(ageField);

        genderLabel = new JLabel("Gender:");
        add(genderLabel);

        genderComboBox = new JComboBox<>(new String[] {"male", "female"});;
        genderComboBox.setSelectedItem("male");
        if (student != null) {
            genderComboBox.setSelectedItem(student.getGender());
        }
        add(genderComboBox);

        phoneLabel = new JLabel("Phone:");
        add(phoneLabel);

        phoneField = new NumericTextField(11);
        if (student != null) {
            phoneField.setText(student.getPhone());
        } // The default value is an empty string
        add(phoneField);

        idCardLabel = new JLabel("IdCard:");
        add(idCardLabel);

        idCardField = new NumericTextField(18);
        if (student != null) {
            idCardField.setText(student.getIdCard());
        } // The default value is an empty string
        add(idCardField);

        collegeLabel = new JLabel("College:");
        add(collegeLabel);

        collegeField = new TextFieldLimit(50);
        if (student != null) {
            collegeField.setText(student.getCollege());
        } // The default value is an empty string
        add(collegeField);

        majorLabel = new JLabel("Major:");
        add(majorLabel);

        majorField = new TextFieldLimit(50);
        if (student != null) {
            majorField.setText(student.getMajor());
        } // The default value is an empty string
        add(majorField);
    }

    public String getId() {
        return idField.getText();
    }

    public String getName() {
        return nameField.getText();
    }

    public int getAge() {
        return ageField.getNumericText();
    }

    public String getGender() {
        return genderComboBox.getSelectedItem().toString();
    }

    public String getPhone() {
        return phoneField.getText();
    }

    public String getIdCard() {
        return idCardField.getText();
    }

    public String getCollege() {
        return collegeField.getText();
    }

    public String getMajor() {
        return majorField.getText();
    }
}
