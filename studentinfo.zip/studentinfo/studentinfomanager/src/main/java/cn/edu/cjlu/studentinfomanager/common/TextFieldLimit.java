package cn.edu.cjlu.studentinfomanager.common;

import javax.swing.*;
import javax.swing.text.*;

/**
 * 
 * @author Zeng Zihuan
 */

public class TextFieldLimit extends JTextField {
    private int limit;
    public TextFieldLimit (int length) {
        super();
        this.limit = length;
        init();
    }
    public void init() {
        ((AbstractDocument) this.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void insertString(FilterBypass fb, int offset, String str, AttributeSet attr) throws BadLocationException {
                if (fb.getDocument().getLength() + str.length() <= limit) {
                    super.insertString(fb, offset, str, attr);
                }
            }

            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
                if (fb.getDocument().getLength() + text.length() - length <= limit) {
                    super.replace(fb, offset, length, text, attrs);
                }
            }
        });
    }
}
