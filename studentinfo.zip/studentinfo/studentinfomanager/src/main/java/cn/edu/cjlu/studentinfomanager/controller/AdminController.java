package cn.edu.cjlu.studentinfomanager.controller;

import cn.edu.cjlu.studentinfomanager.dao.StudentDAO;
import cn.edu.cjlu.studentinfomanager.entity.Student;
import cn.edu.cjlu.studentinfomanager.util.Utils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * 
 * @author Zeng Zihuan
 */

public class AdminController extends JFrame{
    private JTable table;
    private StudentDAO studentDAO;
    private StudentManagerController studentManagerController;
    private AdminController that;

    public AdminController() {
        super("Student Information Management System");
        studentDAO = StudentDAO.getInstance(); // Suppose this is an instance of your StudentDAO class
        that = this;
        initUI();
        studentManagerController = new StudentManagerController(this);
    }

    private void initUI() {

        setLayout(new BorderLayout());
        setSize(600, 400);
        setLocationRelativeTo(null); //Displays in the center of the screen
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create table models and tables
        String[] columns = {"Student ID", "Name", "Age", "Gender", "Phone", "ID Card", "College", "Major"};
        List<Student> allStudents = studentDAO.getAllStudents();// Suppose getAllStudents() is a method of your StudentDAO class that gets data for all students
        String[][] data = Utils.convertStudentToStrings(allStudents);

        DefaultTableModel model = new DefaultTableModel(data, columns);
        table = new JTable(model) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Add a table to the center of the window
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Add
        JButton addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addStudent(); // Let's say this is how you modify student information
            }
        });

        // edit
        JButton modifyButton = new JButton("Update");
        modifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Gets the currently selected row and prints its value
                int viewRow = table.getSelectedRow();
                TableModel tableModel = table.getModel();
                if (viewRow >= 0) { // Check for selected rows
                    int modelRow = table.convertRowIndexToModel(viewRow);
                    String id = tableModel.getValueAt(modelRow, 0).toString();
                    String name = tableModel.getValueAt(modelRow, 1).toString();
                    int age = Integer.parseInt(tableModel.getValueAt(modelRow, 2).toString());
                    String gender = tableModel.getValueAt(modelRow, 3).toString();
                    String phone = tableModel.getValueAt(modelRow, 4).toString();
                    String idCard = tableModel.getValueAt(modelRow, 5).toString();
                    String college = tableModel.getValueAt(modelRow, 6).toString();
                    String major = tableModel.getValueAt(modelRow, 7).toString();
                    Student student = new Student(id, name, age, gender, phone, idCard, college, major);
                    updateStudent(student); // Let's say this is how you modify student information

                } else {
                    JOptionPane.showMessageDialog(that, "No row selected.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Add
        JButton deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int viewRow = table.getSelectedRow();
                TableModel tableModel = table.getModel();
                if (viewRow >= 0) { // Check for selected rows
                    int modelRow = table.convertRowIndexToModel(viewRow);
                    String id = tableModel.getValueAt(modelRow, 0).toString();
                    deleteStudent(id); // Let's say this is how you modify student information
                } else {
                    JOptionPane.showMessageDialog(that, "No row selected.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Add a key to the south of the window
        JPanel southPanel = new JPanel();
        southPanel.add(addButton);
        southPanel.add(modifyButton);
        southPanel.add(deleteButton);
        this.add(southPanel, BorderLayout.SOUTH);
    }

    public void flushTable() {
        // After modifying the students, refresh the Table
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear table data

        List<Student> allStudents = studentDAO.getAllStudents();// Suppose getAllStudents() is a method of your StudentDAO class that gets data for all students
        String[][] data = Utils.convertStudentToStrings(allStudents);

        for (int i = 0; i < data.length; i++) {
            model.addRow(data[i]);
        }
    };
    private void addStudent() {
        studentManagerController.addStudent();
    }
    // To modify the student's method, you need to implement specific logic to get the database connection and update the data以上翻译结果来自有道神经网络翻译（YNMT）· 通用场景

    private void updateStudent(Student student) {
        studentManagerController.updateStudent(student);
    }

    private void deleteStudent(String id) {
        studentManagerController.deleteStudent(id);
    }
}
