package cn.edu.cjlu.studentinfomanager.controller;

import cn.edu.cjlu.studentinfomanager.entity.Student;
import cn.edu.cjlu.studentinfomanager.service.AccountService;
import cn.edu.cjlu.studentinfomanager.service.StudentInfoManagerService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 
 * @author Wang Yi
 */

public class MainController extends JFrame{
    private JFrame that;

    public MainController() {
        super("Student Information Management System");
        that = this;
        initUI();
    }

    public void initUI() {
        setLayout(new BorderLayout());
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); //Displays in the center of the screen

        addLoginPannel();

        this.pack();
        this.setVisible(true);
    }
    public void addLoginPannel() {
        JPanel loginPanel = new JPanel();

        loginPanel.setLayout(new GridLayout(2, 2)); //Layout form
        JLabel idLabel = new JLabel("School ID:");
        idLabel.setHorizontalTextPosition(JLabel.CENTER);
        idLabel.setFont(new Font("Serif", Font.BOLD, 18));
        idLabel.setPreferredSize(new Dimension(100, 30)); // Set preferred size
        loginPanel.add(idLabel);

        // Create text boxes Create text boxes for users and passwords
        JTextField idField = new JTextField();
        idField.setFont(new Font("Serif", Font.PLAIN, 18));
        loginPanel.add(idField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Serif", Font.BOLD, 18));
        passwordLabel.setPreferredSize(new Dimension(100, 30)); // Set preferred size
        loginPanel.add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        idField.setFont(new Font("Serif", Font.PLAIN, 18));
        passwordField.setEchoChar('*');
        loginPanel.add(passwordField);

        // Add a keyboard event listener so that a login event is triggered when the Enter key is hit
        idField.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "loginAction");
        idField.getActionMap().put("loginAction", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login(idField.getText(), new String(passwordField.getPassword()), loginPanel);
            }
        });

        passwordField.getInputMap().put(KeyStroke.getKeyStroke("ENTER"), "loginAction");
        passwordField.getActionMap().put("loginAction", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login(idField.getText(), new String(passwordField.getPassword()), loginPanel);
            }
        });


        // Add a key to the south of the window
        JPanel southPanel = new JPanel();

        // Create a button and add a click event listener
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(50, 90, 80, 25);
        southPanel.add(loginButton);
        add(southPanel, BorderLayout.SOUTH);


        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login(idField.getText(), new String(passwordField.getPassword()), loginPanel);
            }
        });


        this.add(loginPanel);
    }

    private void login(String id, String password, JPanel loginPanel) {
        AccountService accountService = AccountService.getInstance();
        // Get the id and role entered and compare them with the data in the database to verify the login information. This part of the code needs to be modified according to the actual database Settings.

        String flag = accountService.login(id, password);
        if (flag == null || flag.length() == 0) {
            JOptionPane.showMessageDialog(loginPanel, "Incorrect user name or password", "error", JOptionPane.ERROR_MESSAGE);
        } else if (flag.equalsIgnoreCase("admin")) {
            AdminController adminController = new AdminController();
            adminController.setVisible(true);
            that.dispose();
        } else if (flag.equalsIgnoreCase("student")) {
            StudentManagerController studentManagerController = new StudentManagerController(null);
            StudentInfoManagerService studentInfoManagerService = StudentInfoManagerService.getInstance();
            Student student = studentInfoManagerService.getStudentInfoById(id);
            studentManagerController.updateStudent(student);
            that.dispose();
        }
    }

}
