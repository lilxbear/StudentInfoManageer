package cn.edu.cjlu.studentinfomanager.controller;

import cn.edu.cjlu.studentinfomanager.common.StudentPanel;
import cn.edu.cjlu.studentinfomanager.entity.Student;
import cn.edu.cjlu.studentinfomanager.service.StudentInfoManagerService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * 
 * @author Fan Jiaying
 */
public class StudentManagerController {

    private AdminController previousFrame;
    private StudentInfoManagerService studentInfoManagerService = StudentInfoManagerService.getInstance();

    public StudentManagerController(AdminController frame) {
        previousFrame = frame;
    }

    public void addStudent() {
        JFrame addStudent = new JFrame("Add Student");
        addStudent.setLocationRelativeTo(null); //Displays in the center of the screen
        addStudent.setLayout(new BorderLayout());
        addStudent.setSize(600, 400);
        addStudent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        addStudentPanel(addStudent);

        addStudent.pack();
        addStudent.setVisible(true);
    }

    private void addStudentPanel(JFrame frame) {
        StudentPanel studentPanel = new StudentPanel();

        // Create a button and add a click event listener
        JPanel southPanel = new JPanel();
        // Create a button and add a click event listener
        JButton submitButton = new JButton("Submit");

        southPanel.add(submitButton);
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the id and role entered and compare them with the data in the database to verify the login information. This part of the code needs to be modified according to the actual database Settings.
                Student student = new Student();
                student.setId(studentPanel.getId());
                student.setName(studentPanel.getName());
                student.setAge(studentPanel.getAge());
                student.setGender(studentPanel.getGender());
                student.setPhone(studentPanel.getPhone());
                student.setIdCard(studentPanel.getIdCard());
                student.setCollege(studentPanel.getCollege());
                student.setMajor(studentPanel.getMajor());
                if (studentInfoManagerService.addStudentInfo(student)) {
                    JOptionPane.showMessageDialog(frame, "Success", "Info", JOptionPane.INFORMATION_MESSAGE);
                    if (previousFrame != null) {
                        previousFrame.flushTable();
                    }
                    frame.dispose();
                } else {
                    JOptionPane.showMessageDialog(frame, "Fail", "Info", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.add(studentPanel);
        frame.add(southPanel, BorderLayout.SOUTH);
    }

    public void updateStudent(Student student) {
        JFrame updateStudent = new JFrame("Update Student Info");
        updateStudent.setLocationRelativeTo(null); 
        updateStudent.setLayout(new BorderLayout());
        updateStudent.setSize(600, 400);
        updateStudent.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        updateStudentPanel(updateStudent, student);

        updateStudent.pack();
        updateStudent.setVisible(true);
    }

    private void updateStudentPanel(JFrame frame, Student student) {
        StudentPanel studentPanel = new StudentPanel(student);
        // Create a button and add a click event listener
        JPanel southPanel = new JPanel();
        // Create a button and add a click event listener
        JButton submitButton = new JButton("Submit");
        southPanel.add(submitButton);
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the id and role entered and compare them with the data in the database to verify the login information. This part of the code needs to be modified according to the actual database Settings.
                Student student = new Student();
                student.setId(studentPanel.getId());
                student.setName(studentPanel.getName());
                student.setAge(studentPanel.getAge());
                student.setGender(studentPanel.getGender());
                student.setPhone(studentPanel.getPhone());
                student.setIdCard(studentPanel.getIdCard());
                student.setCollege(studentPanel.getCollege());
                student.setMajor(studentPanel.getMajor());

                if (studentInfoManagerService.updateStudentInfo(student)) {
                    JOptionPane.showMessageDialog(frame, "Success", "Info", JOptionPane.INFORMATION_MESSAGE);
                    if (previousFrame != null) {
                        previousFrame.flushTable();
                        frame.dispose();
                    }
                } else {
                    JOptionPane.showMessageDialog(frame, "Fail", "Info", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        JButton cancelButton = new JButton("Cancel");
        southPanel.add(cancelButton);
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });


        frame.add(studentPanel);
        frame.add(southPanel, BorderLayout.SOUTH);
    }

    public void deleteStudent(String id) {
        String message = String.format("Do you want to delete the student with ID %s", id);
        int choice = JOptionPane.showConfirmDialog(null, message, "Conform", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION && studentInfoManagerService.deleteStudentInfo(id)) {
            JOptionPane.showMessageDialog(null, "Success", "Info", JOptionPane.INFORMATION_MESSAGE);
            if (previousFrame != null) {
                previousFrame.flushTable();
            }
        }
    }
}
