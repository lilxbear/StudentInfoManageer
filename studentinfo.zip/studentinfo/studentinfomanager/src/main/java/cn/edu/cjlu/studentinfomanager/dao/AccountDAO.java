package cn.edu.cjlu.studentinfomanager.dao;

import cn.edu.cjlu.studentinfomanager.entity.Account;

import java.sql.*;

/**
 * 
 * @author Zeng Zihuan
 */

public class AccountDAO {
    private Connection connection;
    private static volatile AccountDAO instance;

    private AccountDAO() {
        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/studentinfo;create=true", "root", "123456");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static AccountDAO getInstance() {
        if (instance == null) {
            synchronized (AccountDAO.class) {
                // Check whether the instance exists. If it does not exist, create the instance
                if (instance == null) {
                    instance = new AccountDAO();
                }
            }
        }
        return instance;
    };

    public boolean addAccount(Account account) {
        String sql = "INSERT INTO account (id, role, password) VALUES (?, ?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, account.getId());
            statement.setString(2, account.getRole());
            statement.setString(3, account.getPassword());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean updateAccount(Account account) {
        String sql = "UPDATE account SET role = ?, password = ? WHERE id = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, account.getRole());
            statement.setString(2, account.getPassword());
            statement.setString(3, account.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean deleteAccountById(String id) {
        String sql = "DELETE FROM account WHERE id = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    public Account getAccountById(String id) {
        String sql = "SELECT * FROM account WHERE id = ?";
        Account account = null;
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                account = new Account(resultSet.getString("id"), resultSet.getString("role"), resultSet.getString("password"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return account;
    }

}
