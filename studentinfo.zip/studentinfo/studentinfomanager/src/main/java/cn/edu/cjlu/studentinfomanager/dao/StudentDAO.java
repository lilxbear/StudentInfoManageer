/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cn.edu.cjlu.studentinfomanager.dao;

/**
 *
 * @author Zeng Zihuan
 */

import cn.edu.cjlu.studentinfomanager.entity.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class StudentDAO {
    private Connection connection;
    private static volatile StudentDAO instance;

    private StudentDAO() {
        try {
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/studentinfo;create=true", "root", "123456");
        } catch (SQLException e) {  
            System.out.println(e.getMessage());  
        }
    }

    public static StudentDAO getInstance() {
        if (instance == null) {
            synchronized (StudentDAO.class) {
                // Check whether the instance exists. If it does not exist, create the instance
                if (instance == null) {
                    instance = new StudentDAO();
                }
            }
        }
        return instance;
    };


    public boolean addStudent(Student student) {
        String sql = "INSERT INTO student (id, name, age, gender, phone, id_card, college, major) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try {  
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, student.getId());
            statement.setString(2, student.getName());
            statement.setInt(3, student.getAge());
            statement.setString(4, student.getGender());
            statement.setString(5, student.getPhone());
            statement.setString(6, student.getIdCard());
            statement.setString(7, student.getCollege());
            statement.setString(8, student.getMajor());
            statement.executeUpdate();  
        } catch (SQLException e) {  
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean updateStudent(Student student) {
        String sql = "UPDATE student SET name = ?, age = ?, gender = ?, phone = ?, id_card = ?, college = ?, major = ? WHERE id = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, student.getName());
            statement.setInt(2, student.getAge());
            statement.setString(3, student.getGender());
            statement.setString(4, student.getPhone());
            statement.setString(5, student.getIdCard());
            statement.setString(6, student.getCollege());
            statement.setString(7, student.getMajor());
            statement.setString(8, student.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }

    public boolean deleteStudent(String id) {
        String sql = "DELETE FROM student WHERE id = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, id);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
        return true;
    }
  
    // Get all students
    public List<Student> getAllStudents() {  
        List<Student> students = new ArrayList<>();  
        String sql = "SELECT * FROM student";  
        try {  
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
//            ResultSet resultSet = statement.executeQuery()
            while (resultSet.next()) {  
                String id = resultSet.getString("id");
                String name = resultSet.getString("name");  
                int age = resultSet.getInt("age");  
                String gender = resultSet.getString("gender");  
                String phone = resultSet.getString("phone");
                String idCard = resultSet.getString("id_card");  
                String college = resultSet.getString("college");  
                String major = resultSet.getString("major");  
                students.add(new Student(id, name, age, gender, phone, idCard, college, major));
            }  
        } catch (SQLException e) {  
            System.out.println(e.getMessage());
        }  
        return students;  
    }  
  
    // Get student information based on ID  
    public Student getStudentById(String id) {
        String sql = "SELECT * FROM student WHERE id = ?";  
        Student student = null;  
        try {  
            PreparedStatement statement = connection.prepareStatement(sql);  
            statement.setString(1, id);
            ResultSet resultSet = statement.executeQuery();  
            if (resultSet.next()) {  
                student = new Student(resultSet.getString("id"), resultSet.getString("name"), resultSet.getInt("age"), resultSet.getString("gender"), resultSet.getString("phone"), resultSet.getString("id_card"), resultSet.getString("college"), resultSet.getString("major"));
            }  
        } catch (SQLException e) {  
            System.out.println(e.getMessage());
        } 
        return student;
    }

}