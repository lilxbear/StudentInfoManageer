/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cn.edu.cjlu.studentinfomanager.entity;

/**
 *
 * @author Fan Jiaying
 */
public class Student {  
    private String id;
    private String name;  
    private int age;  
    private String gender;  
    private String phone;  
    private String idCard;  
    private String college;  
    private String major;  
  
    // Constructors  
    public Student() {  
    }
  
    public Student(String id, String name, int age, String gender, String phone, String idCard, String college, String major) {
        this.id = id;  
        this.name = name;  
        this.age = age;  
        this.gender = gender;  
        this.phone = phone;  
        this.idCard = idCard;  
        this.college = college;  
        this.major = major;  
    }
  
    // Getters and Setters  
    public String getId() {
        return id;
    }  
  
    public void setId(String id) {
        this.id = id;  
    }  
  
    public String getName() {  
        return name;  
    }  
  
    public void setName(String name) {  
        this.name = name;  
    }  
  
    public int getAge() {  
        return age;  
    }  
  
    public void setAge(int age) {  
        this.age = age;  
    }  
  
    public String getGender() {  
        return gender;  
    }  
  
    public void setGender(String gender) {  
        this.gender = gender;  
    }  
  
    public String getPhone () {
        return phone;  
    }  
  
    public void setPhone(String phone) {
        this.phone = phone;
    }  
  
    public String getIdCard() {  
        return idCard;  
    }  
  
    public void setIdCard(String idCard) {  
        this.idCard = idCard;  
    }  
  
    public String getCollege() {  
        return college;  
    }  
  
    public void setCollege(String college) {  
        this.college = college;  
    }  
  
    public String getMajor() {  
        return major;  
    }  
  
    public void setMajor(String major) {  
        this.major = major;  
    }  

}
