package cn.edu.cjlu.studentinfomanager.service;

import cn.edu.cjlu.studentinfomanager.dao.AccountDAO;
import cn.edu.cjlu.studentinfomanager.entity.Account;


public class AccountService {
    private static volatile AccountService instance;
    AccountDAO accountDAO = AccountDAO.getInstance();
    private AccountService() {};

    public static AccountService getInstance() {
        if (instance == null) {
            synchronized (AccountService.class) {
                // Check whether the instance exists. If it does not exist, create the instance
                if (instance == null) {
                    instance = new AccountService();
                }
            }
        }
        return instance;
    };

//    AccountDAO.getInstance()
    public String login(String id, String password){
        Account account = accountDAO.getAccountById(id);
        if (account != null && account.getPassword().equals(password)) {
            return account.getRole();
        }
        return "";
    }


}
