package cn.edu.cjlu.studentinfomanager.service;

import cn.edu.cjlu.studentinfomanager.dao.AccountDAO;
import cn.edu.cjlu.studentinfomanager.dao.StudentDAO;
import cn.edu.cjlu.studentinfomanager.entity.Account;
import cn.edu.cjlu.studentinfomanager.entity.Student;

public class StudentInfoManagerService {
    private static volatile StudentInfoManagerService instance;
    StudentDAO studentDAO = StudentDAO.getInstance();
    AccountDAO accountDAO = AccountDAO.getInstance();
    private StudentInfoManagerService() {};

    public static StudentInfoManagerService getInstance() {
        if (instance == null) {
            synchronized (AccountService.class) {
                // Check whether the instance exists. If it does not exist, create the instance
                if (instance == null) {
                    instance = new StudentInfoManagerService();
                }
            }
        }
        return instance;
    };

    public Student getStudentInfoById(String id) {
        return studentDAO.getStudentById(id);
    }

    public boolean addStudentInfo(Student student) {
        boolean addStudentFlag = studentDAO.addStudent(student);
        if (!addStudentFlag) {
            return false;
        }
        Account account = new Account(student.getId(), "student", student.getIdCard().substring(11, 17));
        boolean addAccountFlag = accountDAO.addAccount(account);
        if (!addAccountFlag) {
            studentDAO.deleteStudent(student.getId());
            return false;
        }
        return true;
    }

    public boolean updateStudentInfo(Student student) {
        return studentDAO.updateStudent(student);
    }

    public boolean deleteStudentInfo(String id) {
        Student student = studentDAO.getStudentById(id);
        boolean deleteStudentFlag = studentDAO.deleteStudent(id);
        if (!deleteStudentFlag) {
            return false;
        }
        boolean deleteAccountFlag = accountDAO.deleteAccountById(id);
        if (!deleteAccountFlag) {
            studentDAO.addStudent(student);
            return false;
        }
        return true;
    }
}
