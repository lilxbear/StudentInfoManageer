package cn.edu.cjlu.studentinfomanager.util;

import cn.edu.cjlu.studentinfomanager.entity.Student;

import java.util.List;

/**
 * 
 * @author Wang Yi
 */

public class Utils {
    public static String[] convertStudentToStrings(Student student) {
        String[] properties = new String[8];
        properties[0] = String.valueOf(student.getId());
        properties[1] = student.getName();
        properties[2] = String.valueOf(student.getAge());
        properties[3] = student.getGender();
        properties[4] = student.getPhone();
        properties[5] = student.getIdCard();
        properties[6] = student.getCollege();
        properties[7] = student.getMajor();
        return properties;
    }

    public static String[][] convertStudentToStrings(List<Student> student) {
        String[][] properties = new String[student.size()][8];
        int i = 0;
        for (Student s: student) {
            properties[i++] = convertStudentToStrings(s);
        }
        return properties;
    }
}
