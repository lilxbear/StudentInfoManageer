package cn.edu.cjlu.studentinfomanager.dao;

import cn.edu.cjlu.studentinfomanager.entity.Account;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 
 * @author Zeng Zihuan
 */

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AccountDAOTest {
    private AccountDAO instance;

    @BeforeEach
    void setUp() {
        instance = AccountDAO.getInstance();
    }

    @Test
    @Order(1)
    void addAccount() {
        Account account = new Account("00000000", "admin", "000000");
        boolean b = instance.addAccount(account);
        assertTrue(b);
    }

    @Test
    @Order(2)
    void getAccountById() {
        Account account = instance.getAccountById("00000000");
        assertNotNull(account);
    }

    @Test
    @Order(3)
    void updateAccount() {
        Account account0 = instance.getAccountById("00000000");
        account0.setPassword("00000000");
        boolean b = instance.updateAccount(account0);
        assertTrue(b);
        Account account1 = instance.getAccountById(account0.getId());
        assertEquals(account0.getId(), account1.getId());
        assertEquals(account0.getRole(), account1.getRole());
        assertEquals(account0.getPassword(), account1.getPassword());
    }

    @Test
    @Order(4)
    void deleteAccountById() {
        boolean b = instance.deleteAccountById("00000000");
        assertTrue(b);
    }


}