package cn.edu.cjlu.studentinfomanager.dao;

import cn.edu.cjlu.studentinfomanager.entity.Student;
import org.junit.jupiter.api.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * 
 * @author Wang Yi
 */

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class StudentDAOTest {
    private StudentDAO instance;

    @BeforeEach
    void setUp() {
        instance = StudentDAO.getInstance();
    }

    @Test
    @Order(1)
    void addStudent() {
        Student student = new Student("2023085210", "Xu yi", 20, "male", "19904141118", "440106200301010010", "School of Information Engineering", "Electronic Information");
        assertTrue(instance.addStudent(student));
    }

    @Test
    @Order(2)
    void getAllStudents() {
        List<Student> allStudents = instance.getAllStudents();
        assertTrue(allStudents.size() > 0);
    }

    @Test
    @Order(3)
    void getStudentById() {
        Student student0 = instance.getStudentById("2023085210");
        Student student1 = new Student("2023085210", "Xu yi", 20, "male", "19904141118", "440106200301010010", "School of Information Engineering", "Electronic Information");
        assertEquals(student0.getId(), student1.getId());
        assertEquals(student0.getName(), student1.getName());
        assertEquals(student0.getAge(), student1.getAge());
        assertEquals(student0.getGender(), student1.getGender());
        assertEquals(student0.getPhone(), student1.getPhone());
        assertEquals(student0.getIdCard(), student1.getIdCard());
        assertEquals(student0.getCollege(), student1.getCollege());
        assertEquals(student0.getMajor(), student1.getMajor());
    }

    @Test
    @Order(4)
    void updateStudent() {
        Student student0 = instance.getStudentById("2023085210");
        student0.setPhone("19904141119");
        boolean b = instance.updateStudent(student0);
        assertTrue(b);
        Student student1 = instance.getStudentById(student0.getId());
        assertEquals(student0.getId(), student1.getId());
        assertEquals(student0.getName(), student1.getName());
        assertEquals(student0.getAge(), student1.getAge());
        assertEquals(student0.getGender(), student1.getGender());
        assertEquals(student0.getPhone(), student1.getPhone());
        assertEquals(student0.getIdCard(), student1.getIdCard());
        assertEquals(student0.getCollege(), student1.getCollege());
        assertEquals(student0.getMajor(), student1.getMajor());
    }

    @Test
    @Order(5)
    void deleteStudent() {
        boolean b = instance.deleteStudent("2023085210");
        assertTrue(b);
        Student student0 = instance.getStudentById("2023085210");
        assertNull(student0);
    }
}